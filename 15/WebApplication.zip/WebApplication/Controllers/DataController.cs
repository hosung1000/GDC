﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Test;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication.Controllers
{
    
    public class DataController : Controller
    {
        [Route("api/Select")]
        [HttpGet]
        public ArrayList Select() //1. Select() 에 파라미터를 받아와서 아래 db.GetReader의 Sql문을 바꿔주자.
        {
            ArrayList resultList = null;
            //Test DB / Real DB
            Database db = new Database(DataBaseInfo.RealDBInfo());
            Hashtable resultMap = db.GetReader("select bNo, bTitle, bContents from [Board];");
            if (Convert.ToInt32(resultMap["MsgCode"]) == -1)
            {
                Console.WriteLine(resultMap["Msg"].ToString());
              
            }
            else
            {
                resultList = (ArrayList)resultMap["Data"];
            }

            return resultList;
        }
    }
}

/*
 CREATE TABLE [dbo].[Board](
       [bNo] [int] IDENTITY(1,1) NOT NULL,
       [bTitle] [varchar](30) NOT NULL,
       [bContents] [varchar](200) NOT NULL,
       [delYn] [varchar](1) NOT NULL DEFAULT ('N'),
       [regDate] [datetime] NOT NULL DEFAULT (getdate())
) ON [PRIMARY]
GO
     */
